Navigate to the bokeh_app directory, then run:

    pip3 install -r requirements.txt (only if you have not already done this step once before)

    bokeh serve --show .
